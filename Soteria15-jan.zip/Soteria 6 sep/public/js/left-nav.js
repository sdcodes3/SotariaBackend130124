function onSizeChange(){
    if(screen.width >= 768){
        document.getElementById('left-nav-close').click();
    }
}