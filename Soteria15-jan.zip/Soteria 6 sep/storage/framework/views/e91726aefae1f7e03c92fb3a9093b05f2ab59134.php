<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard</title>
    <!-- Google Font CDN -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Nunito&display=swap" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Spline+Sans&display=swap" rel="stylesheet">

    <!-- Bootstrap CSS CDN 5.2 -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/css/bootstrap.min.css">
    <!-- Link CSS -->
    <link rel="stylesheet" href="style/dashboard.css">
    <link rel="stylesheet" href="style/left-nav.css">
    <!-- FontAwesome CDN -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" integrity="sha512-iecdLmaskl7CVkqkXNQ/ZH/XLlvWZOJyj7Yy7tcenmpD1ypASozpmT/E0iPtmFIB46ZmdtAc9eNBvH0H/ZpiBw==" crossorigin="anonymous" referrerpolicy="no-referrer" />
</head>
<body class="dashboard">
    <div class="row g-0">
        <!-- Left navbar -->
        <div class="col-12 col-md-3 col-xxl-2 left-nav d-none d-md-block">
            <div class="p-4 py-2">
                <img src="img/DashboardSotariaLogo.png" alt="" class="img-fluid" style="padding-top: 0.3rem; padding-bottom: 0.3rem;">
            </div>
            <a href="index.html" class="btn text-start p-0 m-0 w-100 outline-0 border-0 rounded-0">
                <div class="d-flex active">
                    <div class="highlight"></div>
                    <div class="py-4 w-100 row g-0 px-2 px-lg-3 align-items-center gap-2 gap-lg-3 flex-nowrap">
                        <div class="col-2">
                            <img src="img/logo-dashboard1.png" alt="" class="img-fluid">
                        </div>
                        <div class="options col">
                            Dashboard
                        </div>
                    </div>
                </div>
            </a>
            <a href="customer1.html" class="btn text-start p-0 m-0 w-100 outline-0 border-0 rounded-0">
                <div class="d-flex">
                    <div class="highlight"></div>
                    <div class="py-4 w-100 row g-0 px-2 px-lg-3 align-items-center gap-2 gap-lg-3 flex-nowrap">
                        <div class="col-2">
                            <img src="img/logo-customer.png" alt="" class="img-fluid">
                        </div>
                        <div class="options col">
                            Customers
                        </div>
                    </div>
                </div>
            </a>
            <a href="agent1.html" class="btn text-start p-0 m-0 w-100 outline-0 border-0 rounded-0">
                <div class="d-flex">
                    <div class="highlight"></div>
                    <div class="py-4 w-100 row g-0 px-2 px-lg-3 align-items-center gap-2 gap-lg-3 flex-nowrap">
                        <div class="col-2">
                            <img src="img/logo-agents.png" alt="" class="img-fluid">
                        </div>
                        <div class="options col">
                            Agents
                        </div>
                    </div>
                </div>
            </a>
            <a href="insurance1.html" class="btn text-start p-0 m-0 w-100 outline-0 border-0 rounded-0">
                <div class="d-flex">
                    <div class="highlight"></div>
                    <div class="py-4 w-100 row g-0 px-2 px-lg-3 align-items-center gap-2 gap-lg-3 flex-nowrap">
                        <div class="col-2">
                            <img src="img/logo-insurance-company.png" alt="" class="img-fluid">
                        </div>
                        <div class="options col">
                            Insurance Company
                        </div>
                    </div>
                </div>
            </a>
            <a href="plan1.html" class="btn text-start p-0 m-0 w-100 outline-0 border-0 rounded-0">
                <div class="d-flex">
                    <div class="highlight"></div>
                    <div class="py-4 w-100 row g-0 px-2 px-lg-3 align-items-center gap-2 gap-lg-3 flex-nowrap">
                        <div class="col-2">
                            <img src="img/logo-plan.png" alt="" class="img-fluid">
                        </div>
                        <div class="options col">
                            Plan/Rate
                        </div>
                    </div>
                </div>
            </a>
            <a href="discount1.html" class="btn text-start p-0 m-0 w-100 outline-0 border-0 rounded-0">
                <div class="d-flex">
                    <div class="highlight"></div>
                    <div class="py-4 w-100 row g-0 px-2 px-lg-3 align-items-center gap-2 gap-lg-3 flex-nowrap">
                        <div class="col-2">
                            <img src="img/logo-discount.png" alt="" class="img-fluid">
                        </div>
                        <div class="options col">
                            Discount Coupon Code
                        </div>
                    </div>
                </div>
            </a>
            <a href="report1.html" class="btn text-start p-0 m-0 w-100 outline-0 border-0 rounded-0">
                <div class="d-flex">
                    <div class="highlight"></div>
                    <div class="py-4 w-100 row g-0 px-2 px-lg-3 align-items-center gap-2 gap-lg-3 flex-nowrap">
                        <div class="col-2">
                            <img src="img/logo-report.png" alt="" class="img-fluid">
                        </div>
                        <div class="options col">
                            Report
                        </div>
                    </div>
                </div>
            </a>
            <a href="privacypolicy1.html" class="btn text-start p-0 m-0 w-100 outline-0 border-0 rounded-0">
                <div class="d-flex">
                    <div class="highlight"></div>
                    <div class="py-4 w-100 row g-0 px-2 px-lg-3 align-items-center gap-2 gap-lg-3 flex-nowrap">
                        <div class="col-2">
                            <img src="img/logo-privacy.png" alt="" class="img-fluid">
                        </div>
                        <div class="options col">
                            Privacy Policy
                        </div>
                    </div>
                </div>
            </a>
            <a href="admin1.html" class="btn text-start p-0 m-0 w-100 outline-0 border-0 rounded-0">
                <div class="d-flex">
                    <div class="highlight"></div>
                    <div class="py-4 w-100 row g-0 px-2 px-lg-3 align-items-center gap-2 gap-lg-3 flex-nowrap">
                        <div class="col-2">
                            <img src="img/logo-add-new.png" alt="" class="img-fluid">
                        </div>
                        <div class="options col">
                            Add New Sub-Admin
                        </div>
                    </div>
                </div>
            </a>
            <a href="renewal1.html" class="btn text-start p-0 m-0 w-100 outline-0 border-0 rounded-0">
                <div class="d-flex">
                    <div class="highlight"></div>
                    <div class="py-4 w-100 row g-0 px-2 px-lg-3 align-items-center gap-2 gap-lg-3 flex-nowrap">
                        <div class="col-2">
                            <img src="img/logo-renewal.png" alt="" class="img-fluid">
                        </div>
                        <div class="options col">
                            Renewal Section
                        </div>
                    </div>
                </div>
            </a>
            <a href="supervisor1.html" class="btn text-start p-0 m-0 w-100 outline-0 border-0 rounded-0">
                <div class="d-flex">
                    <div class="highlight"></div>
                    <div class="py-4 w-100 row g-0 px-2 px-lg-3 align-items-center gap-2 gap-lg-3 flex-nowrap">
                        <div class="col-2">
                            <img src="img/logo-add-supervisor.png" alt="" class="img-fluid">
                        </div>
                        <div class="options col">
                            Add Supervisor
                        </div>
                    </div>
                </div>
            </a>
        </div>
        <!-- Left navbar offcanvas -->
        <div class="offcanvas offcanvas-start" id="leftNav">
            <div class="offcanvas-body p-0 m-0">
                <div class="col-12 col-md-3 col-xxl-2 left-nav">
                    <div class="p-4 py-3 d-flex align-items-center justify-content-between">
                        <img src="img/DashboardSotariaLogo.png" alt="" class="img-fluid">
                        <div><button type="button" class="btn-close" data-bs-dismiss="offcanvas" aria-label="Close" id="left-nav-close"></button></div>
                    </div>
                    <a href="index.html" class="btn text-start p-0 m-0 w-100 outline-0 border-0 rounded-0">
                        <div class="d-flex active">
                            <div class="highlight"></div>
                            <div class="py-4 w-100 row g-0 px-3 align-items-center gap-2 gap-lg-3 flex-nowrap">
                                <div class="col-1">
                                    <img src="img/logo-dashboard1.png" alt="" class="img-fluid">
                                </div>
                                <div class="options col">
                                    Dashboard
                                </div>
                            </div>
                        </div>
                    </a>
                    <a href="customer1.html" class="btn text-start p-0 m-0 w-100 outline-0 border-0 rounded-0">
                        <div class="d-flex">
                            <div class="highlight"></div>
                            <div class="py-4 w-100 row g-0 px-3 align-items-center gap-2 gap-lg-3 flex-nowrap">
                                <div class="col-1">
                                    <img src="img/logo-customer.png" alt="" class="img-fluid">
                                </div>
                                <div class="options col">
                                    Customers
                                </div>
                            </div>
                        </div>
                    </a>
                    <a href="agent1.html" class="btn text-start p-0 m-0 w-100 outline-0 border-0 rounded-0">
                        <div class="d-flex">
                            <div class="highlight"></div>
                            <div class="py-4 w-100 row g-0 px-3 align-items-center gap-2 gap-lg-3 flex-nowrap">
                                <div class="col-1">
                                    <img src="img/logo-agents.png" alt="" class="img-fluid">
                                </div>
                                <div class="options col">
                                    Agents
                                </div>
                            </div>
                        </div>
                    </a>
                    <a href="insurance1.html" class="btn text-start p-0 m-0 w-100 outline-0 border-0 rounded-0">
                        <div class="d-flex">
                            <div class="highlight"></div>
                            <div class="py-4 w-100 row g-0 px-3 align-items-center gap-2 gap-lg-3 flex-nowrap">
                                <div class="col-1">
                                    <img src="img/logo-insurance-company.png" alt="" class="img-fluid">
                                </div>
                                <div class="options col">
                                    Insurance Company
                                </div>
                            </div>
                        </div>
                    </a>
                    <a href="plan1.html" class="btn text-start p-0 m-0 w-100 outline-0 border-0 rounded-0">
                        <div class="d-flex">
                            <div class="highlight"></div>
                            <div class="py-4 w-100 row g-0 px-3 align-items-center gap-2 gap-lg-3 flex-nowrap">
                                <div class="col-1">
                                    <img src="img/logo-plan.png" alt="" class="img-fluid">
                                </div>
                                <div class="options col">
                                    Plan/Rate
                                </div>
                            </div>
                        </div>
                    </a>
                    <a href="discount1.html" class="btn text-start p-0 m-0 w-100 outline-0 border-0 rounded-0">
                        <div class="d-flex">
                            <div class="highlight"></div>
                            <div class="py-4 w-100 row g-0 px-3 align-items-center gap-2 gap-lg-3 flex-nowrap">
                                <div class="col-1">
                                    <img src="img/logo-discount.png" alt="" class="img-fluid">
                                </div>
                                <div class="options col">
                                    Discount Coupon Code
                                </div>
                            </div>
                        </div>
                    </a>
                    <a href="report1.html" class="btn text-start p-0 m-0 w-100 outline-0 border-0 rounded-0">
                        <div class="d-flex">
                            <div class="highlight"></div>
                            <div class="py-4 w-100 row g-0 px-3 align-items-center gap-2 gap-lg-3 flex-nowrap">
                                <div class="col-1">
                                    <img src="img/logo-report.png" alt="" class="img-fluid">
                                </div>
                                <div class="options col">
                                    Report
                                </div>
                            </div>
                        </div>
                    </a>
                    <a href="privacypolicy1.html" class="btn text-start p-0 m-0 w-100 outline-0 border-0 rounded-0">
                        <div class="d-flex">
                            <div class="highlight"></div>
                            <div class="py-4 w-100 row g-0 px-3 align-items-center gap-2 gap-lg-3 flex-nowrap">
                                <div class="col-1">
                                    <img src="img/logo-privacy.png" alt="" class="img-fluid">
                                </div>
                                <div class="options col">
                                    Privacy Policy
                                </div>
                            </div>
                        </div>
                    </a>
                    <a href="admin1.html" class="btn text-start p-0 m-0 w-100 outline-0 border-0 rounded-0">
                        <div class="d-flex">
                            <div class="highlight"></div>
                            <div class="py-4 w-100 row g-0 px-3 align-items-center gap-2 gap-lg-3 flex-nowrap">
                                <div class="col-1">
                                    <img src="img/logo-add-new.png" alt="" class="img-fluid">
                                </div>
                                <div class="options col">
                                    Add New Sub-Admin
                                </div>
                            </div>
                        </div>
                    </a>
                    <a href="renewal1.html" class="btn text-start p-0 m-0 w-100 outline-0 border-0 rounded-0">
                        <div class="d-flex">
                            <div class="highlight"></div>
                            <div class="py-4 w-100 row g-0 px-3 align-items-center gap-2 gap-lg-3 flex-nowrap">
                                <div class="col-1">
                                    <img src="img/logo-renewal.png" alt="" class="img-fluid">
                                </div>
                                <div class="options col">
                                    Renewal Section
                                </div>
                            </div>
                        </div>
                    </a>
                    <a href="supervisor1.html" class="btn text-start p-0 m-0 w-100 outline-0 border-0 rounded-0">
                        <div class="d-flex">
                            <div class="highlight"></div>
                            <div class="py-4 w-100 row g-0 px-3 align-items-center gap-2 gap-lg-3 flex-nowrap">
                                <div class="col-1">
                                    <img src="img/logo-add-supervisor.png" alt="" class="img-fluid">
                                </div>
                                <div class="options col">
                                    Add Supervisor
                                </div>
                            </div>
                        </div>
                    </a>
                </div>
            </div>
        </div>
        <!-- Main Content -->
        <div class="col main d-flex flex-column">
            <nav class="d-flex justify-content-between align-items-center px-2 px-md-4" style="padding-bottom: 0.75rem; padding-top: 0.75rem;">
                <div class="d-md-none ps-2">
                    <button class="navbar-toggler" type="button" data-bs-toggle="offcanvas" href="#leftNav" aria-controls="leftNav">
                        <i class="fas fa-bars"></i>
                    </button>
                </div>
                <div class="title">
                    Dashboard/Main Page
                </div>
                <div class="d-flex gap-3">
                    <div>
                        <button class="btn border border-2 circle">
                            <img src="img/notification.png" alt="" class="img-fluid">
                        </button>
                    </div>
                    <div >
                        <button class="btn border profile circle"></button>
                    </div>
                </div>
            </nav>
        </div>
    </div>
    <!-- Bootstrap Script CDN 5.2 -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/js/bootstrap.bundle.min.js"></script>
    <script src="script/left-nav.js"></script>
</body>
</html><?php /**PATH C:\xampp\htdocs\soteria\resources\views/layouts/sidebar.blade.php ENDPATH**/ ?>